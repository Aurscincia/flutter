import 'package:flutter/material.dart';
import 'package:camera/camera.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:google_ml_kit/google_ml_kit.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await requestCameraPermission();
  runApp(MyApp());
}

Future<void> requestCameraPermission() async {
  var status = await Permission.camera.request();
  if (status != PermissionStatus.granted) {
    throw Exception('Camera permission not granted');
  }
}

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  late CameraController _controller;
  late Future<void> _initializeControllerFuture;
  late Future<void> getAvailableCameras = availableCameras(); // Correction

  @override
  void initState() {
    super.initState();
    _initializeControllerFuture = initializeCamera();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('Camera App'),
        ),
        body: FutureBuilder<void>(
          future: _initializeControllerFuture,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.done) {
              return CameraPreview(_controller);
            } else {
              return Center(child: CircularProgressIndicator());
            }
          },
        ),
        floatingActionButton: FloatingActionButton(
          child: Icon(Icons.camera_alt),
          onPressed: takePicture,
        ),
      ),
    );
  }

  Future<void> initializeCamera() async {
  // Attendez la résolution du Future et récupérez la liste des caméras
  List<CameraDescription> cameras = await getAvailableCameras;

  // Choisissez la caméra désirée (généralement la première)
  _controller = CameraController(cameras.first, ResolutionPreset.medium);
  await _controller.initialize();
  setState(() {});
}


  Future<void> takePicture() async {
    // Take the picture
    XFile picture = await _controller.takePicture();

    // Convert the picture to a bytes buffer
    List<int> bytes = await picture.readAsBytes();

    // Create a TextRecognizer
    TextRecognizer textRecognizer = GoogleMlKit.vision.textRecognizer();

    // Recognize the text in the picture
    RecognizedText text = await textRecognizer.processImage(bytes);

    // Access the list of text blocks
    List<TextBlock> textBlocks = text.blocks;

    // Print the recognized text
    print(textBlocks);
  }
}
